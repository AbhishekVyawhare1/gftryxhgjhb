package com.example.College.collegeserviceIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.College.Repository.CollegeRepository;
import com.example.College.entities.College;
import com.example.College.exceptions.ResourceNotFoundException;
import com.example.College.service.CollegeService;


@Service
public class CollegeServiceImpl implements CollegeService{

	@Autowired
	private CollegeRepository collegerepo;
	
	
	@Override
	public College create(College college) {
		return collegerepo.save(college);
		
	}

	@Override
	public List<College> getAll() {
		return collegerepo.findAll();
		
	}

	@Override
	public College Get(String id) {
		return collegerepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Not Found College"));
	}

	public String Delete(String id) {
	collegerepo.deleteById(id);
	return "Deleted SuccessFully";
	}

}
