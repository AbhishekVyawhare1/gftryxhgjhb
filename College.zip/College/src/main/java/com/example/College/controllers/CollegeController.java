package com.example.College.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.College.collegeserviceIMPL.CollegeServiceImpl;
import com.example.College.entities.College;

@RestController
@RequestMapping("/abhi")
public class CollegeController {

	@Autowired
	private CollegeServiceImpl repos;
	
	
	//create College
	@PostMapping
	public ResponseEntity<College> createCollege( @RequestBody College college){
		return ResponseEntity.status(HttpStatus.CREATED).body(repos.create(college));
	}
	
	//GetAll Colleges
	@GetMapping
	public ResponseEntity<List<College>> GetAllColleges(){
		return ResponseEntity.status(HttpStatus.OK).body(repos.getAll());
	}
	
	//getById
	@GetMapping("/{id}")
	public ResponseEntity<College>  GetById(@PathVariable String id){
		return ResponseEntity.status(HttpStatus.OK).body(repos.Get(id));
	}
	
	//DeleteById
	@DeleteMapping("/{id}")
	public ResponseEntity<String> DeleteById(@PathVariable String id){
		return ResponseEntity.status(HttpStatus.OK).body(repos.Delete(id));
	}
}
