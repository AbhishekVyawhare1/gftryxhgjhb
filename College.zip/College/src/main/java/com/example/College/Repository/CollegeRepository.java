package com.example.College.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.College.entities.College;

public interface CollegeRepository extends MongoRepository<College, String>{

}
