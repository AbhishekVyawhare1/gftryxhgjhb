package com.example.College.service;

import java.util.List;

import com.example.College.entities.College;


public interface CollegeService {

	
	//create 
	College create(College college);
	
	//getAll
	
	List<College> getAll();
	
	
	//getID
	College Get(String id);
	
	//Delete By Id
	String Delete(String id);
	
}
